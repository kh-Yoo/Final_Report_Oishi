package com.example.buy_and_purchase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class cafe_latte extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe_latte);
    }
}

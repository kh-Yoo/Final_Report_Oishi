package com.example.sub_menu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Buy_behavior extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_behavior);

        TextView number_counting = (TextView)findViewById(R.id.count_number);
        TextView Menu_naming = (TextView)findViewById(R.id.menu_name);
        TextView Menu_price = (TextView)findViewById(R.id.price);

        Intent intent = getIntent(); /*데이터 수신*/
        int number = intent.getExtras().getInt("number"); /*Int형*/
        int price = intent.getExtras().getInt("price");
        String name = intent.getExtras().getString("name"); /*String형*/
        number_counting.setText("주문 수량 : " + number);
        Menu_naming.setText("주문한 메뉴 : " + name);
        Menu_price.setText("주문 가격 : " + (price * number));
    }


}

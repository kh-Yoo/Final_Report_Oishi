package com.example.sub_menu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Matrix;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import javax.xml.datatype.Duration;

public class menu_detail extends AppCompatActivity {
    int count = 0;
    String  name;
    int price = 3000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_detail);

        final Button purchase_button = (Button)findViewById(R.id.purchase);
        final Button up_button = (Button)findViewById(R.id.count_up);
        final Button down_button = (Button)findViewById(R.id.count_down);
        final TextView count_text = (TextView) findViewById(R.id.count_number);
        final TextView menu_name = (TextView) findViewById(R.id.title);

        name = menu_name.getText().toString();

        up_button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v){
                count++;
                count_text.setText(""+count);
            }

        });

        down_button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v){
                count--;
                if(count < 0){
                    count = 0;}
                count_text.setText(""+count);
            }

        });

        purchase_button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v){
                if(count < 1)
                {
                    Toast.makeText(getApplicationContext(),"주문할 물건을 1개 이상 담아주세요",Toast.LENGTH_LONG).show();
                }
                else {
                    Intent intent = new Intent(getApplicationContext(), Buy_behavior.class);
                    intent.putExtra("number", count); /*송신*/
                    intent.putExtra("name", name);
                    intent.putExtra("price", price);
                    startActivity(intent);
                }
            }

        });
    }
}
